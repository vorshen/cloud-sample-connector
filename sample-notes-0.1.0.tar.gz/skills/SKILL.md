---
name: sample-notes
description: 记录一条示例笔记，用来走通连接器安装。
---
# 示例笔记
这是一个本地示例连接器，只用于确认添加流程。
